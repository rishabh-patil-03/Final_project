# Credits
## Source Sounds
- [Pixabay](https://pixabay.com/sound-effects/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=music&amp;utm_content=43861)
- [Freesound](https://freesound.org/)
- [Google Speech - Translate](https://translate.google.com/)