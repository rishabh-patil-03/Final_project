// config.js
const config = {
    backendServer: 'http://18.191.166.16:5000',
    frontendServer: 'http://18.191.166.16:8080'
  };
  
export default config;
  